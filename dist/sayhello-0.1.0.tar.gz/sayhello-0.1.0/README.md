
The package has a module that says hello